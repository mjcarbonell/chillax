// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};

// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        rows: [],
        meows: [],
        search_filter: "",
        content: "",
        followList: [],
        current: "",
        currentID: 999, 
    };    
    
    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };    

    app.clear_search = function () {
        app.vue.search_filter = "";
    };
    
    app.set_follow = function (row_idx) {
        console.log("in set follow");
        // console.log(row_idx); 
        // console.log(app.vue.currentID);
        // console.log(app.vue.rows[row_idx].username);
        
        if (app.vue.rows[row_idx].currentID == app.vue.currentID){
            app.set_unfollow(row_idx); 
            return; 
        }

        axios.post(follow_url,
            {
                user_name: app.vue.rows[row_idx].username,
                uid: app.vue.currentID,
            }).then(function (response) {
                // app.vue.rows[row_idx].currentID = app.vue.currentID; 
                let r = app.vue.rows[row_idx];
                let new_r = {}; 
                new_r.currentID = app.vue.currentID; 
                new_r.username = r.username; 
                new_r._idx = row_idx; 
                Vue.set(app.vue.rows, row_idx, new_r); 
        }) 
        console.log("RESPONSE");
        console.log(app.vue.followList);
        console.log(app.vue.rows);
    };

    app.set_unfollow = function (row_idx) {
        console.log("in unfollow");
        let user_name = app.vue.rows[row_idx].username; 
        axios.get(unfollow_url, {params: {user_name: user_name}}).then(function (response){
            let r = app.vue.rows[row_idx];
            let new_r = {};
            new_r.currentID = 999; 
            new_r.username = r.username; 
            new_r._idx = r._idx; 
            Vue.set(app.vue.rows, row_idx, new_r); 
            console.log("changed");
        })
        // app.init(); 
    }; 

    app.add_meow = function () {
        console.log("in add meow");
        axios.post(meow_url,
            {
                user_name: app.vue.rows[app.vue.currentID].username,
                content: app.vue.content,
            }).then(function (response) {
                // app.vue.rows[row_idx].currentID = app.vue.currentID; 
                console.log("done");
                app.vue.meows.push({
                    author: app.vue.rows[app.vue.currentID].username,
                    content: app.vue.content,
                    timestamp: response.data.ts, 
                });
                app.enumerate(app.vue.meows);
                Vue.set(app.vue, 'content', ''); // Set app.vue.content to an empty string
        })
    }

    app.formatTime = function (timestamp) {
        console.log("in format time");
        const now = new Date(Date.now());
        const timestampDate = new Date(timestamp);
        now.setHours(now.getHours() + 7)
        const diff = Math.floor((now - timestampDate) / 1000); // Time difference in seconds
        if (diff < 10) {
        return 'just now';
        } else if (diff < 60) {
        return `${diff} seconds ago`;
        } else if (diff < 3600) {
        const minutes = Math.floor(diff / 60);
        return `${minutes} minutes ago`;
        } else if (diff < 86400) {
        const hours = Math.floor(diff / 3600);
        return `${hours} hours ago`;
        } else {
        const days = Math.floor(diff / 86400);
        return `${days} days ago`;
        }
    }

    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        clear_search: app.clear_search,
        set_follow: app.set_follow,
        set_unfollow: app.set_unfollow, 
        add_meow: app.add_meow, 
        formatTime: app.formatTime,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        axios.get(get_users_url).then(function (response){
            app.vue.rows = app.enumerate(response.data.rows);
            app.vue.meows = app.enumerate(response.data.meows);
            app.vue.current = response.data.current; 
            // followList gurantees we get users followed by current user 
            app.vue.followList = app.enumerate(response.data.followList);  
            // Rows is now just all the auth users in database 
            for (let r of app.vue.rows) {
                if (app.vue.current === r.email) {
                    app.vue.currentID = r._idx; // FINDING THE OWNERS INDEX 
                }
            }
            console.log("owner index ");
            console.log(app.vue.currentID);
            //adding those in the following database to the rows. 
            for (let i of app.vue.followList) {
                const existsInRows = app.vue.rows.some((row) => row.username === i.user_name);
                const existingRow = app.vue.rows.find((row) => row.username === i.user_name);
                if (!existsInRows) {
                    // console.log("adding");
                    // console.log(i.user_name);
                  app.vue.rows.push({
                    username: i.user_name,
                    currentID: app.vue.currentID,
                  });
                }
                else{
                    existingRow.currentID = app.vue.currentID;
                }
            }
            app.vue.rows = app.enumerate(response.data.rows); // enumerate rows
            console.log("FIRST");
            console.log(app.vue.rows);
            console.log(app.vue.followList);
        })
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code in it. 
init(app);
